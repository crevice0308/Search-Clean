#!/usr/bin/env python3
"""Rebuild the release without downloading tools or including dependencies."""
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
import hashlib

root = Path(__file__).resolve().parents[1]
output = root.parent / "Search-Clean-Lite-1.0.0.zip"
prefix = "Search-Clean-Lite-1.0.0"
with ZipFile(output, "w", ZIP_DEFLATED, compresslevel=9) as archive:
    for path in sorted(root.rglob("*")):
        if not path.is_file() or any(part in {"node_modules", "__pycache__", ".git"} for part in path.parts):
            continue
        if path.suffix in {".pyc", ".log", ".zip"}:
            continue
        archive.write(path, f"{prefix}/{path.relative_to(root).as_posix()}")
print(f"{output}\n{output.stat().st_size} bytes\nSHA256 {hashlib.sha256(output.read_bytes()).hexdigest()}")
